package zhu.filer

import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.text.format.Formatter
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.*
import java.io.File
import java.util.*

class FindHelper(
    private val activity: AppCompatActivity,
    private val currentDir: () -> File,
    private val loadDir: suspend (File) -> Unit,
    private val locateFile: (File) -> Unit
) {

    private var dialog: Dialog? = null
    private var findQuery: String = ""
    private var searchJob: Job? = null

    fun show(query: String, recursive: Boolean = true) {
        findQuery = query
        searchJob?.cancel()
        searchJob = null

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val topRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dpToPx(activity, 8), 0, dpToPx(activity, 8))
        }

        val iconContainer = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(
                dpToPx(activity, 32),
                dpToPx(activity, 32)
            )
            val lp = layoutParams as LinearLayout.LayoutParams
            lp.leftMargin = dpToPx(activity, 16)
            layoutParams = lp
        }

        val progress = ProgressBar(activity).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            visibility = View.INVISIBLE
        }
        iconContainer.addView(progress)

        val doneIcon = TextView(activity).apply {
            text = "✓"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(getThemeColor(android.R.attr.colorPrimary, Color.parseColor("#6200EE")))
            visibility = View.INVISIBLE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        iconContainer.addView(doneIcon)

        topRow.addView(iconContainer)

        val countText = TextView(activity).apply {
            textSize = 14f
            text = "已找到 0 个"
            visibility = View.VISIBLE
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.leftMargin = dpToPx(activity, 12)
            lp.weight = 1f
            layoutParams = lp
        }
        topRow.addView(countText)

        val primaryColor = getThemeColor(android.R.attr.colorPrimary, Color.parseColor("#6200EE"))
        val colorStateList = ColorStateList.valueOf(primaryColor)

        val stopButton = MaterialButton(activity).apply {
            text = "结束"
            textSize = 14f
            visibility = View.INVISIBLE
            setBackgroundColor(primaryColor)
            setTextColor(Color.WHITE)
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.gravity = Gravity.END
            lp.rightMargin = dpToPx(activity, 16)
            layoutParams = lp
            setOnClickListener {
                searchJob?.cancel()
                progress.visibility = View.INVISIBLE
                doneIcon.visibility = View.VISIBLE
                text = "已结束"
                setBackgroundColor(Color.TRANSPARENT)
                setTextColor(colorStateList)
                strokeWidth = dpToPx(activity, 1)
                strokeColor = colorStateList
                isEnabled = false
                alpha = 0.6f
            }
        }
        topRow.addView(stopButton)

        root.addView(topRow)

        val listContainer = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(activity, 400)
            )
        }

        val rv = RecyclerView(activity).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            layoutManager = LinearLayoutManager(activity)
            visibility = View.GONE
        }
        listContainer.addView(rv)

        val emptyHint = TextView(activity).apply {
            text = "未找到匹配文件"
            textSize = 16f
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        listContainer.addView(emptyHint)

        root.addView(listContainer)

        dialog = MaterialAlertDialogBuilder(activity)
            .setTitle("查找结果")
            .setView(root)
            .setNegativeButton("关闭") { _, _ -> }
            .show()

        val recyclerView = rv
        val progressBar = progress
        val doneView = doneIcon
        val emptyView = emptyHint
        val countView = countText
        val stopView = stopButton
        val container = iconContainer

        val adapter = FileListAdapter(
            onItemClick = { file, _ ->
                searchJob?.cancel()
                dialog?.dismiss()
                if (file.isDirectory) {
                    activity.lifecycleScope.launch { loadDir(file) }
                } else {
                    locateFile(file)
                }
            },
            onItemLongClick = { _, _ ->
                false
            }
        )
        recyclerView.adapter = adapter

        searchJob = activity.lifecycleScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.VISIBLE
                progressBar.alpha = 1f
                doneView.visibility = View.INVISIBLE
                countView.text = "已找到 0 个"
                stopView.visibility = View.VISIBLE
                stopView.text = "结束"
                stopView.setBackgroundColor(primaryColor)
                stopView.setTextColor(Color.WHITE)
                stopView.strokeWidth = 0
                stopView.strokeColor = ColorStateList.valueOf(Color.TRANSPARENT)
                stopView.isEnabled = true
                stopView.alpha = 1f
                recyclerView.isVisible = false
                emptyView.isVisible = false
            }

            var foundCount = 0
            val queue: Queue<File> = LinkedList()
            queue.add(currentDir())
            while (isActive && queue.isNotEmpty()) {
                val dir = queue.poll()
                val files = dir.listFiles() ?: continue
                for (file in files) {
                    if (!isActive) break
                    if (file.isDirectory) {
                        if (recursive) queue.add(file)
                    } else if (file.name.contains(query, ignoreCase = true)) {
                        val timeStr = DATE_FORMAT.format(Date(file.lastModified()))
                        val sizeStr = Formatter.formatFileSize(activity, file.length())
                        val subtitle = "$timeStr  $sizeStr"
                        val item = FileItem(file, file.name, "📄", subtitle)
                        foundCount++
                        withContext(Dispatchers.Main) {
                            if (!isActive || dialog == null || !dialog!!.isShowing) return@withContext
                            countView.text = "已找到 $foundCount 个"
                            adapter.addItem(item)
                            recyclerView.isVisible = true
                        }
                    }
                }
            }

            withContext(Dispatchers.Main) {
                if (!isActive || dialog == null || !dialog!!.isShowing) return@withContext
                progressBar.visibility = View.INVISIBLE
                doneView.visibility = View.VISIBLE
                stopView.text = "已结束"
                stopView.setBackgroundColor(Color.TRANSPARENT)
                stopView.setTextColor(colorStateList)
                stopView.strokeWidth = dpToPx(activity, 1)
                stopView.strokeColor = colorStateList
                stopView.isEnabled = false
                stopView.alpha = 0.6f

                if (foundCount == 0) {
                    emptyView.isVisible = true
                    recyclerView.isVisible = false
                    countView.text = "找到 0 个"
                } else {
                    emptyView.isVisible = false
                    recyclerView.isVisible = true
                    countView.text = "找到 $foundCount 个"
                }
            }
        }
    }

    fun dismiss() {
        searchJob?.cancel()
        dialog?.dismiss()
        dialog = null
    }

    private fun getThemeColor(attr: Int, fallback: Int): Int {
        val typedValue = TypedValue()
        return if (activity.theme.resolveAttribute(attr, typedValue, true)) {
            typedValue.data
        } else {
            fallback
        }
    }
}